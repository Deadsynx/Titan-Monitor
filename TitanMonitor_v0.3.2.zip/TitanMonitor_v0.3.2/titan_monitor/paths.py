"""Gestion centralisée des chemins, compatible avec PyInstaller."""

import os
import sys
from pathlib import Path


def project_root() -> Path:
    """Retourne la racine des ressources embarquées ou du projet source."""
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent.parent


def resource_path(filename: str) -> Path:
    """Retourne le chemin vers une ressource livrée avec l'application."""
    return project_root() / filename


def app_data_dir() -> Path:
    """Dossier persistant de l'utilisateur."""
    root = Path(os.environ.get("LOCALAPPDATA", Path.home()))
    path = root / "Titan Monitor"
    path.mkdir(parents=True, exist_ok=True)
    return path


def log_dir() -> Path:
    """Dossier des journaux CSV."""
    path = app_data_dir() / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path
