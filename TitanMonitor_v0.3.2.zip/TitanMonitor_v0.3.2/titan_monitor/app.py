"""Cycle de vie principal de Titan Monitor."""

import os

import webview

from .api import Api
from .constants import (
    MAIN_WINDOW_MIN_SIZE,
    MAIN_WINDOW_SIZE,
    OVERLAY_TITLE,
    OVERLAY_WINDOW_POSITION,
    OVERLAY_WINDOW_SIZE,
    WINDOW_TITLE,
)
from .sensors import SensorReader
from .storage import CsvLogger, open_log_folder
from .settings import SettingsStore
from .settings_interface import SETTINGS_HTML
from .tray import TrayController
from .web_interface import HTML, OVERLAY_HTML


class TitanMonitorApp:
    """Orchestre les fenêtres, les capteurs, le tray et l'arrêt propre."""

    def __init__(self) -> None:
        self.main_window = None
        self.overlay_window = None
        self.settings_window = None
        self.overlay_visible = False
        self.quitting = False
        self.sensors = SensorReader()
        self.settings = SettingsStore()
        self.logger = CsvLogger()
        self.tray = TrayController(
            show_window=self.show_window,
            hide_window=self.hide_window,
            toggle_overlay=self.toggle_overlay,
            show_settings=self.show_settings,
            open_logs=open_log_folder,
            quit_application=self.quit,
        )
        self.api = Api(
            self.sensors, self.logger, self.tray, self.hide_overlay,
            self.settings, self.hide_settings,
        )

    def show_window(self, icon=None, item=None) -> None:
        if self.main_window is not None:
            try:
                self.main_window.show()
                self.main_window.restore()
            except Exception:
                pass

    def hide_window(self, icon=None, item=None) -> None:
        if self.main_window is not None:
            try:
                self.main_window.hide()
            except Exception:
                pass

    def show_overlay(self, icon=None, item=None) -> None:
        if self.overlay_window is not None:
            try:
                self.overlay_window.show()
                self.overlay_window.restore()
                self.overlay_visible = True
            except Exception:
                pass

    def hide_overlay(self, icon=None, item=None) -> None:
        if self.overlay_window is not None:
            try:
                self.overlay_window.hide()
                self.overlay_visible = False
            except Exception:
                pass


    def show_settings(self, icon=None, item=None) -> None:
        if self.settings_window is not None:
            try:
                self.settings_window.show()
                self.settings_window.restore()
            except Exception:
                pass

    def hide_settings(self, icon=None, item=None) -> None:
        if self.settings_window is not None:
            try:
                self.settings_window.hide()
            except Exception:
                pass

    def toggle_overlay(self, icon=None, item=None) -> None:
        if self.overlay_visible:
            self.hide_overlay()
        else:
            self.show_overlay()

    def _on_main_closing(self):
        if self.quitting:
            return True
        self.hide_window()
        return False

    def _on_settings_closing(self):
        if self.quitting:
            return True
        self.hide_settings()
        return False

    def _on_overlay_closing(self):
        if self.quitting:
            return True
        self.hide_overlay()
        return False

    def quit(self, icon=None, item=None) -> None:
        self.quitting = True
        self.tray.stop()
        try:
            self.sensors.close()
        finally:
            if self.settings_window is not None:
                try:
                    self.settings_window.destroy()
                except Exception:
                    pass
            if self.overlay_window is not None:
                try:
                    self.overlay_window.destroy()
                except Exception:
                    pass
            if self.main_window is not None:
                try:
                    self.main_window.destroy()
                except Exception:
                    os._exit(0)

    def run(self) -> None:
        width, height = MAIN_WINDOW_SIZE
        min_width, min_height = MAIN_WINDOW_MIN_SIZE
        overlay_width, overlay_height = OVERLAY_WINDOW_SIZE
        overlay_x, overlay_y = OVERLAY_WINDOW_POSITION

        current_settings = self.settings.get()

        self.main_window = webview.create_window(
            WINDOW_TITLE,
            html=HTML,
            js_api=self.api,
            width=width,
            height=height,
            min_size=(min_width, min_height),
            background_color="#090c11",
            on_top=current_settings["always_on_top"],
            hidden=current_settings["start_minimized"],
        )
        self.settings_window = webview.create_window(
            "Paramètres — Titan Monitor",
            html=SETTINGS_HTML,
            js_api=self.api,
            width=780,
            height=690,
            min_size=(650, 560),
            hidden=True,
            background_color="#070b10",
        )
        self.overlay_window = webview.create_window(
            OVERLAY_TITLE,
            html=OVERLAY_HTML,
            js_api=self.api,
            width=overlay_width,
            height=overlay_height,
            x=overlay_x,
            y=overlay_y,
            frameless=True,
            transparent=True,
            on_top=True,
            easy_drag=True,
            hidden=not current_settings["overlay_at_startup"],
            background_color="#000000",
        )
        self.main_window.events.closing += self._on_main_closing
        self.settings_window.events.closing += self._on_settings_closing
        self.overlay_window.events.closing += self._on_overlay_closing
        self.tray.start()
        self.overlay_visible = current_settings["overlay_at_startup"]
        webview.start()


def run() -> None:
    TitanMonitorApp().run()
