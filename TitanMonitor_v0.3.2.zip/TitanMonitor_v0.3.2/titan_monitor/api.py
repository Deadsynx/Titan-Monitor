"""Pont Python vers JavaScript exposé aux fenêtres pywebview."""

from .sensors import SensorReader
from .storage import CsvLogger
from .tray import TrayController
from .settings import SettingsStore


class Api:
    def __init__(
        self,
        sensors: SensorReader,
        logger: CsvLogger,
        tray: TrayController,
        hide_overlay,
        settings: SettingsStore,
        hide_settings,
    ) -> None:
        self._sensors = sensors
        self._logger = logger
        self._tray = tray
        self._hide_overlay = hide_overlay
        self._settings = settings
        self._hide_settings = hide_settings

    def get_temps(self):
        try:
            data = self._sensors.read()
            self._logger.append(data)
            return {"ok": True, "data": data}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def get_overlay_data(self):
        try:
            return {"ok": True, "data": self._sensors.read()}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def hide_overlay(self):
        self._hide_overlay()
        return {"ok": True}

    def report_critical(self, label, value):
        try:
            numeric_value = float(value)
            self._tray.set_state("critical")
            self._tray.notify_critical(str(label), numeric_value)
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def update_tray_state(self, state):
        try:
            self._tray.set_state(str(state))
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def get_settings(self):
        try:
            return {"ok": True, "settings": self._settings.get()}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def save_settings(self, updates):
        try:
            settings = self._settings.update(dict(updates or {}))
            return {"ok": True, "settings": settings}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def hide_settings(self):
        self._hide_settings()
        return {"ok": True}
