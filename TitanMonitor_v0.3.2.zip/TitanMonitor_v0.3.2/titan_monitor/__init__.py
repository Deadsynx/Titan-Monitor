"""Titan Monitor — monitoring matériel cyberpunk."""

from .constants import APP_VERSION

__all__ = ["APP_VERSION"]
