"""Interface HTML de la fenêtre Paramètres."""

SETTINGS_HTML = r"""
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Paramètres — Titan Monitor</title>
<style>
:root{--bg:#070b10;--panel:#0c141b;--border:#203440;--green:#6be07d;--text:#d8eef2;--dim:#7895a0;--red:#ff5b5b}
*{box-sizing:border-box}html,body{margin:0;min-height:100%;background:linear-gradient(145deg,#05080c,#0a1016);color:var(--text);font-family:"Segoe UI",Arial,sans-serif}
body{padding:22px}.title{font-size:24px;letter-spacing:3px;color:var(--green);font-weight:700}.subtitle{color:var(--dim);margin:4px 0 20px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.card{background:rgba(12,20,27,.94);border:1px solid var(--border);border-radius:12px;padding:16px;box-shadow:0 0 22px rgba(107,224,125,.04)}
h2{font-size:13px;letter-spacing:2px;color:var(--green);margin:0 0 14px}.row{display:flex;align-items:center;justify-content:space-between;gap:15px;margin:12px 0;color:#c9dde2}.row label{flex:1}
input[type=checkbox]{width:18px;height:18px;accent-color:var(--green)}input[type=number]{width:82px;background:#071016;color:var(--text);border:1px solid #29414e;border-radius:7px;padding:7px;text-align:right}
.actions{display:flex;justify-content:flex-end;gap:10px;margin-top:18px}.btn{border:1px solid #31505e;background:#0c1820;color:var(--text);padding:10px 18px;border-radius:8px;cursor:pointer}.btn.primary{border-color:var(--green);color:var(--green)}.btn:hover{filter:brightness(1.2)}
#status{min-height:20px;color:var(--green);margin-top:12px;text-align:right}.note{font-size:12px;color:var(--dim);line-height:1.45;margin-top:10px}@media(max-width:650px){.grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="title">TITAN // SETTINGS</div>
<div class="subtitle">Version 0.3 — configuration persistante</div>
<div class="grid">
<section class="card"><h2>GÉNÉRAL</h2>
<div class="row"><label>Démarrer avec Windows</label><input id="start_with_windows" type="checkbox"></div>
<div class="row"><label>Démarrer réduit dans le tray</label><input id="start_minimized" type="checkbox"></div>
<div class="row"><label>Afficher l’overlay au démarrage</label><input id="overlay_at_startup" type="checkbox"></div>
<div class="row"><label>Fenêtre principale toujours au-dessus</label><input id="always_on_top" type="checkbox"></div>
<div class="note">Le mode « toujours au-dessus » est appliqué au prochain lancement pour une compatibilité maximale avec pywebview.</div>
</section>
<section class="card"><h2>APPARENCE & ALERTES</h2>
<div class="row"><label>Notifications Windows</label><input id="notifications_enabled" type="checkbox"></div>
<div class="row"><label>Glitch rouge critique</label><input id="glitch_enabled" type="checkbox"></div>
<div class="row"><label>Pluie Matrix</label><input id="matrix_enabled" type="checkbox"></div>
<div class="row"><label>Scanlines</label><input id="scanlines_enabled" type="checkbox"></div>
</section>
<section class="card"><h2>SEUILS CRITIQUES</h2>
<div class="row"><label>GPU Hotspot</label><span><input id="gpu_hotspot_critical" type="number" min="50" max="120"> °C</span></div>
<div class="row"><label>GPU Core</label><span><input id="gpu_core_critical" type="number" min="50" max="120"> °C</span></div>
<div class="row"><label>CPU</label><span><input id="cpu_critical" type="number" min="50" max="120"> °C</span></div>
<div class="row"><label>Jonction mémoire</label><span><input id="memory_junction_critical" type="number" min="50" max="120"> °C</span></div>
</section>
<section class="card"><h2>AVERTISSEMENT</h2>
<div class="row"><label>Passage en orange avant le seuil</label><span><input id="warning_margin" type="number" min="1" max="30"> °C</span></div>
<div class="note">Exemple : seuil critique à 90 °C et marge à 10 °C → état orange dès 80 °C.</div>
</section>
</div>
<div id="status"></div>
<div class="actions"><button class="btn" onclick="closeSettings()">Fermer</button><button class="btn primary" onclick="saveSettings()">Enregistrer</button></div>
<script>
const keys=['start_with_windows','start_minimized','overlay_at_startup','always_on_top','notifications_enabled','glitch_enabled','matrix_enabled','scanlines_enabled','gpu_hotspot_critical','gpu_core_critical','cpu_critical','memory_junction_critical','warning_margin'];
async function loadSettings(){const r=await window.pywebview.api.get_settings();if(!r.ok)return;for(const k of keys){const e=document.getElementById(k);if(e.type==='checkbox')e.checked=!!r.settings[k];else e.value=r.settings[k];}}
async function saveSettings(){const data={};for(const k of keys){const e=document.getElementById(k);data[k]=e.type==='checkbox'?e.checked:Number(e.value);}const r=await window.pywebview.api.save_settings(data);const s=document.getElementById('status');s.textContent=r.ok?'✓ Paramètres enregistrés':'Erreur : '+r.error;setTimeout(()=>s.textContent='',2500);}
function closeSettings(){window.pywebview.api.hide_settings();}
window.addEventListener('pywebviewready',loadSettings);
</script>
</body>
</html>
"""
