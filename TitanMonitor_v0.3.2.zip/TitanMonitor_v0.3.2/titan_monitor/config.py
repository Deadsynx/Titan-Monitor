"""Filtres et constantes de Titan Monitor."""

SENSOR_FILTERS = [
    ["gpu temperature", "temperature gpu", "gpu core"],
    ["gpu hot spot", "hotspot", "point chaud"],
    ["memory junction", "jonction de memoire", "jonction memoire"],
    ["cpu package", "boitier cpu", "package"],
    ["ccd"],
    ["tctl/tdie", "core max", "cpu (tctl"],
    ["thermal sensor critical", "critical temperature"],
]

LOAD_FILTERS = [
    ["cpu total"],
    ["gpu core"],
    ["memory", "ram"],
]

CSV_LOG_INTERVAL = 10.0
