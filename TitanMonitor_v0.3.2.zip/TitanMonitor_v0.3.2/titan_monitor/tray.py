"""Icône de zone de notification, menu et notifications Windows."""

import threading
import time
from collections.abc import Callable

import pystray
from PIL import Image, ImageDraw

from .constants import NOTIFICATION_COOLDOWN_SECONDS, TRAY_NOTIFICATION_RESET_SECONDS
from .paths import resource_path


class TrayController:
    VALID_STATES = {"normal", "warning", "critical"}

    def __init__(
        self,
        show_window: Callable,
        hide_window: Callable,
        toggle_overlay: Callable,
        show_settings: Callable,
        open_logs: Callable,
        quit_application: Callable,
    ) -> None:
        self._show_window = show_window
        self._hide_window = hide_window
        self._toggle_overlay = toggle_overlay
        self._show_settings = show_settings
        self._open_logs = open_logs
        self._quit_application = quit_application
        self._icon = None
        self._state = "normal"
        self._last_notification_at = 0.0
        self._notification_lock = threading.Lock()

    @staticmethod
    def _make_image(state: str = "normal") -> Image.Image:
        icon_path = resource_path("titan_monitor.ico")
        try:
            image = Image.open(icon_path).convert("RGBA").resize((64, 64))
        except Exception:
            image = Image.new("RGBA", (64, 64), (6, 10, 14, 255))
            draw = ImageDraw.Draw(image)
            draw.ellipse((7, 7, 57, 57), outline=(107, 224, 125, 255), width=4)
            draw.text((22, 15), "T", fill=(207, 233, 239, 255))

        overlays = {
            "warning": (255, 165, 35, 68),
            "critical": (255, 35, 35, 88),
        }
        if state in overlays:
            image = Image.alpha_composite(
                image, Image.new("RGBA", image.size, overlays[state])
            )
            draw = ImageDraw.Draw(image)
            badge = (255, 182, 55, 255) if state == "warning" else (255, 55, 55, 255)
            draw.ellipse((42, 42, 62, 62), fill=badge, outline=(245, 245, 245, 230), width=2)
        return image

    def start(self) -> None:
        menu = pystray.Menu(
            pystray.MenuItem("Afficher Titan Monitor", self._show_window, default=True),
            pystray.MenuItem("Masquer", self._hide_window),
            pystray.MenuItem("Afficher / masquer l’overlay", self._toggle_overlay),
            pystray.MenuItem("Paramètres", self._show_settings),
            pystray.MenuItem("Ouvrir le dossier des logs", self._open_logs),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quitter", self._quit_application),
        )
        self._icon = pystray.Icon(
            "titan_monitor",
            self._make_image(),
            "Titan Monitor — températures système",
            menu,
        )
        self._icon.run_detached()

    def stop(self) -> None:
        if self._icon is not None:
            self._icon.stop()

    def set_state(self, state: str) -> None:
        state = state if state in self.VALID_STATES else "normal"
        if state == self._state:
            return
        self._state = state
        if self._icon is None:
            return

        labels = {
            "normal": "Titan Monitor — système stable",
            "warning": "Titan Monitor — température élevée",
            "critical": "Titan Monitor — alerte thermique",
        }
        try:
            self._icon.icon = self._make_image(state)
            self._icon.title = labels[state]
        except Exception:
            pass

    def notify_critical(self, label: str, value: float) -> None:
        now = time.monotonic()
        with self._notification_lock:
            if now - self._last_notification_at < NOTIFICATION_COOLDOWN_SECONDS:
                return
            self._last_notification_at = now

        if self._icon is None:
            return
        try:
            self._icon.icon = self._make_image("critical")
            self._icon.notify(
                f"{label} : {value:.1f} °C — seuil critique dépassé",
                "TITAN MONITOR — ALERTE THERMIQUE",
            )
            threading.Timer(
                TRAY_NOTIFICATION_RESET_SECONDS,
                self._restore_current_state_image,
            ).start()
        except Exception:
            pass

    def _restore_current_state_image(self) -> None:
        if self._icon is not None:
            try:
                self._icon.icon = self._make_image(self._state)
            except Exception:
                pass
