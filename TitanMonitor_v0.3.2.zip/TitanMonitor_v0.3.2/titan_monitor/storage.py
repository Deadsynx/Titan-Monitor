"""Historique CSV et ouverture des dossiers persistants."""

import csv
import os
import threading
import time
from datetime import datetime
from typing import Iterable, Mapping, Any

from .config import CSV_LOG_INTERVAL
from .paths import log_dir


class CsvLogger:
    """Enregistre périodiquement les mesures sans bloquer l'interface."""

    def __init__(self, interval: float = CSV_LOG_INTERVAL) -> None:
        self.interval = float(interval)
        self._lock = threading.Lock()
        self._last_log_at = 0.0

    def append(self, data: Iterable[Mapping[str, Any]]) -> None:
        now_mono = time.monotonic()
        if now_mono - self._last_log_at < self.interval:
            return
        self._last_log_at = now_mono

        stamp = datetime.now()
        target = log_dir() / f"titan_monitor_{stamp:%Y-%m-%d}.csv"
        new_file = not target.exists()

        with self._lock, target.open("a", newline="", encoding="utf-8-sig") as fh:
            writer = csv.writer(fh, delimiter=";")
            if new_file:
                writer.writerow([
                    "Horodatage", "Capteur", "Type", "Valeur", "Unité",
                    "Minimum", "Maximum", "Moyenne",
                ])
            for row in data:
                writer.writerow([
                    stamp.strftime("%Y-%m-%d %H:%M:%S"), row.get("label", ""),
                    row.get("kind", ""), row.get("value", ""), row.get("unit", ""),
                    row.get("vmin", ""), row.get("vmax", ""), row.get("vavg", ""),
                ])


def open_log_folder(icon=None, item=None) -> None:
    """Ouvre le dossier des journaux sous Windows."""
    try:
        os.startfile(str(log_dir()))
    except (AttributeError, OSError):
        pass
