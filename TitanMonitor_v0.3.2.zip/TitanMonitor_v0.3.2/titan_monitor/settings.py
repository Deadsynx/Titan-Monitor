"""Paramètres persistants de Titan Monitor."""

from __future__ import annotations

import json
import os
import sys
import winreg
from copy import deepcopy
from pathlib import Path
from threading import RLock

from .paths import app_data_dir

DEFAULT_SETTINGS = {
    "start_with_windows": False,
    "start_minimized": False,
    "overlay_at_startup": False,
    "always_on_top": False,
    "notifications_enabled": True,
    "glitch_enabled": True,
    "matrix_enabled": True,
    "scanlines_enabled": True,
    "gpu_hotspot_critical": 90,
    "gpu_core_critical": 95,
    "cpu_critical": 95,
    "memory_junction_critical": 96,
    "warning_margin": 10,
}


class SettingsStore:
    """Charge, valide et sauvegarde les réglages dans LOCALAPPDATA."""

    def __init__(self) -> None:
        self._path = app_data_dir() / "settings.json"
        self._lock = RLock()
        self._settings = self._load()

    def _load(self) -> dict:
        data = deepcopy(DEFAULT_SETTINGS)
        try:
            if self._path.exists():
                loaded = json.loads(self._path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    data.update(loaded)
        except Exception:
            pass
        return self._validate(data)

    @staticmethod
    def _validate(data: dict) -> dict:
        clean = deepcopy(DEFAULT_SETTINGS)
        for key, default in DEFAULT_SETTINGS.items():
            value = data.get(key, default)
            if isinstance(default, bool):
                clean[key] = bool(value)
            elif isinstance(default, int):
                try:
                    value = int(value)
                except (TypeError, ValueError):
                    value = default
                clean[key] = max(1, min(120, value))
            else:
                clean[key] = value
        clean["warning_margin"] = max(1, min(30, clean["warning_margin"]))
        return clean

    def get(self) -> dict:
        with self._lock:
            return deepcopy(self._settings)

    def update(self, updates: dict) -> dict:
        with self._lock:
            merged = dict(self._settings)
            if isinstance(updates, dict):
                merged.update(updates)
            self._settings = self._validate(merged)
            self._path.parent.mkdir(parents=True, exist_ok=True)
            self._path.write_text(
                json.dumps(self._settings, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            self._apply_windows_startup(self._settings["start_with_windows"])
            return deepcopy(self._settings)

    @staticmethod
    def _launch_command() -> str:
        if getattr(sys, "frozen", False):
            return f'"{sys.executable}"'
        script = Path(sys.argv[0]).resolve()
        return f'"{sys.executable}" "{script}"'

    def _apply_windows_startup(self, enabled: bool) -> None:
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        try:
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                key_path,
                0,
                winreg.KEY_SET_VALUE,
            ) as key:
                if enabled:
                    winreg.SetValueEx(
                        key,
                        "Titan Monitor",
                        0,
                        winreg.REG_SZ,
                        self._launch_command(),
                    )
                else:
                    try:
                        winreg.DeleteValue(key, "Titan Monitor")
                    except FileNotFoundError:
                        pass
        except OSError:
            pass
