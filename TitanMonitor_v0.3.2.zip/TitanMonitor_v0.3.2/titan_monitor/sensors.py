"""Lecture thread-safe des capteurs via LibreHardwareMonitorLib."""

import threading
import unicodedata
from typing import Any

from HardwareMonitor.Hardware import Computer, SensorType, IVisitor

from .config import LOAD_FILTERS, SENSOR_FILTERS


def _normalize(text: str) -> str:
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    return text.lower()


def _select_by_filters(results, filter_groups, pad_with_top=0):
    selected = []
    seen_labels = set()

    for group in filter_groups:
        for result in results:
            if result["label"] in seen_labels:
                continue
            normalized_label = _normalize(result["label"])
            if any(_normalize(keyword) in normalized_label for keyword in group):
                selected.append(result)
                seen_labels.add(result["label"])

    if pad_with_top and len(selected) < pad_with_top:
        for result in sorted(results, key=lambda item: item["value"], reverse=True):
            if result["label"] not in seen_labels:
                selected.append(result)
                seen_labels.add(result["label"])
            if len(selected) >= pad_with_top:
                break

    return selected


class _UpdateVisitor(IVisitor):
    __namespace__ = "TitanMonitor"

    def VisitComputer(self, computer):
        computer.Traverse(self)

    def VisitHardware(self, hardware):
        hardware.Update()
        for sub_hardware in hardware.SubHardware:
            sub_hardware.Update()

    def VisitParameter(self, parameter):
        pass

    def VisitSensor(self, sensor):
        pass


class SensorReader:
    """Possède l'instance LibreHardwareMonitor et sérialise les lectures."""

    def __init__(self) -> None:
        self._computer = None
        self._visitor = _UpdateVisitor()
        self._lock = threading.Lock()

    def _get_computer(self):
        if self._computer is None:
            computer = Computer()
            computer.IsCpuEnabled = True
            computer.IsGpuEnabled = True
            computer.IsMemoryEnabled = True
            computer.IsMotherboardEnabled = True
            computer.Open()
            self._computer = computer
        return self._computer

    @staticmethod
    def _iter_sensors(hardware):
        yield from hardware.Sensors
        for sub_hardware in hardware.SubHardware:
            yield from sub_hardware.Sensors

    def read(self) -> list[dict[str, Any]]:
        with self._lock:
            computer = self._get_computer()
            computer.Accept(self._visitor)

            temperatures = []
            loads = []

            for hardware in computer.Hardware:
                for sensor in self._iter_sensors(hardware):
                    if sensor.Value is None:
                        continue

                    label = str(sensor.Name).strip()
                    if not label:
                        continue

                    value = float(sensor.Value)
                    minimum = float(sensor.Min) if sensor.Min is not None else value
                    maximum = float(sensor.Max) if sensor.Max is not None else value
                    entry = {
                        "label": label,
                        "value": round(value, 1),
                        "vmin": round(minimum, 1),
                        "vmax": round(maximum, 1),
                        "vavg": round((minimum + maximum) / 2, 1),
                    }

                    if sensor.SensorType == SensorType.Temperature:
                        entry.update(unit="°C", kind="temp")
                        temperatures.append(entry)
                    elif sensor.SensorType == SensorType.Load:
                        entry.update(unit="%", kind="load")
                        loads.append(entry)

            if not temperatures and not loads:
                raise RuntimeError(
                    "Aucun capteur trouvé. Lance Titan Monitor EN ADMINISTRATEUR "
                    "pour autoriser la lecture du matériel."
                )

            selected_temperatures = _select_by_filters(
                temperatures, SENSOR_FILTERS, pad_with_top=6
            )[:8]
            selected_loads = _select_by_filters(loads, LOAD_FILTERS)
            return selected_temperatures + selected_loads

    def close(self) -> None:
        with self._lock:
            if self._computer is not None:
                self._computer.Close()
                self._computer = None
