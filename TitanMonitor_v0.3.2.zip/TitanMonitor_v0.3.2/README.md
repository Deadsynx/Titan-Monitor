# Titan Monitor v0.3

Version stable avec fenêtre de paramètres persistants.

## Lancement

Ouvrir un CMD en administrateur dans le dossier :

```cmd
python -m pip install -r requirements.txt
python main.py
```

## Paramètres

Clic droit sur l'icône Titan Monitor près de l'horloge, puis **Paramètres**.

Les réglages sont enregistrés dans :

```text
%LOCALAPPDATA%\Titan Monitor\settings.json
```

Les options de seuil et d'apparence sont appliquées immédiatement lors du prochain rafraîchissement ou après réouverture de l'application. Les options de démarrage et « toujours au-dessus » prennent pleinement effet au lancement suivant.

## Compilation

```cmd
build.bat
```

L'exécutable est créé dans `dist\Titan Monitor.exe`.
