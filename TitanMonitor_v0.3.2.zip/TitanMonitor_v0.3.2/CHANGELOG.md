# Titan Monitor 0.3.1

- Corrige les températures normales affichées en rouge dans l’overlay.
- Ignore les sondes firmware « Critical Low/High » dans l’overlay.
- Sécurise les seuils chargés depuis les paramètres.

# Changelog

## 0.3.0

- Ajout d’une vraie fenêtre **Paramètres** accessible depuis le System Tray.
- Sauvegarde persistante dans `%LOCALAPPDATA%\Titan Monitor\settings.json`.
- Seuils configurables pour GPU Hotspot, GPU Core, CPU et jonction mémoire.
- Marge d’avertissement orange configurable.
- Options pour les notifications, le glitch, la pluie Matrix et les scanlines.
- Démarrage avec Windows via la clé utilisateur `Run`.
- Options de démarrage réduit, overlay au lancement et fenêtre toujours au-dessus.

## 0.2.0

- Refactorisation interne sans changement visuel volontaire.
- Ajout de `TitanMonitorApp`, `SensorReader`, `TrayController` et `CsvLogger`.
- Séparation du pont JavaScript dans `api.py`.
- Centralisation des chemins dans `paths.py`.
