@echo off
setlocal
cd /d "%~dp0"
python -m PyInstaller --noconfirm --clean --onefile --noconsole --uac-admin ^
  --icon=assets\titan_monitor.ico ^
  --collect-all HardwareMonitor --collect-all clr_loader --collect-all pythonnet ^
  --hidden-import=pystray._win32 ^
  --add-data="assets\titan_monitor.ico;." ^
  --name="Titan Monitor" main.py
if errorlevel 1 pause & exit /b 1
echo.
echo EXE cree dans dist\Titan Monitor.exe
pause
