L’installateur Inno Setup sera ajouté après validation de cette base structurée.
