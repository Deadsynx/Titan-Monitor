#!/usr/bin/env python3
from titan_monitor.app import run

if __name__ == "__main__":
    run()
